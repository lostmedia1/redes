CREATE TABLE mensajes (
    id SERIAL PRIMARY KEY,
    protocolo VARCHAR(10),
    data TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
